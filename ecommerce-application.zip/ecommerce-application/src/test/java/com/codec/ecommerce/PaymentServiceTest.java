package com.codec.ecommerce;

import com.codec.ecommerce.exception.BadRequestException;
import com.codec.ecommerce.service.PaymentService;
import org.junit.jupiter.api.Test;

import java.math.BigDecimal;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

class PaymentServiceTest {

    private final PaymentService service = new PaymentService();
    private final BigDecimal amount = new BigDecimal("100.00");

    @Test
    void approvesValidCard() {
        assertTrue(service.charge("CARD", "4242 4242 4242 4242", amount).success());
    }

    @Test
    void declinesCardEndingInZeros() {
        assertFalse(service.charge("CARD", "4242424242420000", amount).success());
    }

    @Test
    void acceptsCashOnDelivery() {
        assertTrue(service.charge("cod", null, amount).success());
    }

    @Test
    void rejectsMalformedCardAndUnknownMethod() {
        assertThrows(BadRequestException.class, () -> service.charge("CARD", "123", amount));
        assertThrows(BadRequestException.class, () -> service.charge("BITCOIN", null, amount));
    }
}
