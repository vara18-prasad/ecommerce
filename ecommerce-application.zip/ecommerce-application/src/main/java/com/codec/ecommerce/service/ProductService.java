package com.codec.ecommerce.service;

import com.codec.ecommerce.exception.ResourceNotFoundException;
import com.codec.ecommerce.model.Product;
import com.codec.ecommerce.repository.ProductRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
public class ProductService {

    private final ProductRepository repo;

    public ProductService(ProductRepository repo) {
        this.repo = repo;
    }

    @Transactional(readOnly = true)
    public List<Product> find(String query, String category) {
        if (query != null && !query.isBlank()) {
            return repo.findByNameContainingIgnoreCase(query.trim());
        }
        if (category != null && !category.isBlank()) {
            return repo.findByCategoryIgnoreCase(category.trim());
        }
        return repo.findAll();
    }

    @Transactional(readOnly = true)
    public Product get(Long id) {
        return repo.findById(id).orElseThrow(() -> new ResourceNotFoundException("Product " + id + " not found"));
    }

    @Transactional
    public Product create(Product product) {
        product.setId(null); // never let a client choose the id
        return repo.save(product);
    }

    @Transactional
    public Product update(Long id, Product changes) {
        Product existing = get(id);
        existing.setName(changes.getName());
        existing.setDescription(changes.getDescription());
        existing.setPrice(changes.getPrice());
        existing.setStock(changes.getStock());
        existing.setCategory(changes.getCategory());
        return repo.save(existing);
    }

    @Transactional
    public void delete(Long id) {
        if (!repo.existsById(id)) {
            throw new ResourceNotFoundException("Product " + id + " not found");
        }
        repo.deleteById(id);
    }
}
