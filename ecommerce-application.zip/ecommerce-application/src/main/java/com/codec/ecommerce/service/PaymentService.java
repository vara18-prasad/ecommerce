package com.codec.ecommerce.service;

import com.codec.ecommerce.exception.BadRequestException;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.util.UUID;

/**
 * Payment SIMULATION - no real gateway is called.
 * <ul>
 *   <li>COD: always accepted.</li>
 *   <li>CARD: needs 16 digits; a number ending in 0000 is declined, anything else is approved.</li>
 * </ul>
 * Card numbers are validated in memory only and are never stored or logged.
 */
@Service
public class PaymentService {

    public record PaymentResult(boolean success, String reference, String message) {
    }

    public PaymentResult charge(String method, String cardNumber, BigDecimal amount) {
        String reference = "PAY-" + UUID.randomUUID().toString().substring(0, 8).toUpperCase();

        if ("COD".equalsIgnoreCase(method)) {
            return new PaymentResult(true, reference, "Cash on delivery - pay when the order arrives");
        }
        if (!"CARD".equalsIgnoreCase(method)) {
            throw new BadRequestException("paymentMethod must be CARD or COD");
        }

        String digits = cardNumber == null ? "" : cardNumber.replaceAll("\\s", "");
        if (!digits.matches("\\d{16}")) {
            throw new BadRequestException("cardNumber must be 16 digits");
        }
        boolean declined = digits.endsWith("0000");
        return new PaymentResult(!declined, reference,
                declined ? "Card declined (simulated)" : "Payment approved (simulated)");
    }
}
