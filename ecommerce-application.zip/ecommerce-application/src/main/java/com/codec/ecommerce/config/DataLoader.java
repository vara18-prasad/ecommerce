package com.codec.ecommerce.config;

import com.codec.ecommerce.model.Product;
import com.codec.ecommerce.repository.ProductRepository;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.math.BigDecimal;
import java.util.List;

/** Seeds a demo catalog the first time the app starts against an empty database. */
@Configuration
public class DataLoader {

    @Bean
    CommandLineRunner seedProducts(ProductRepository repo) {
        return args -> {
            if (repo.count() > 0) {
                return;
            }
            repo.saveAll(List.of(
                    product("Wireless Mouse", "2.4 GHz ergonomic wireless mouse", "799.00", 50, "Electronics"),
                    product("Mechanical Keyboard", "Blue-switch keyboard with backlight", "3499.00", 25, "Electronics"),
                    product("USB-C Hub", "7-in-1 hub with HDMI and card reader", "1299.00", 40, "Electronics"),
                    product("Bluetooth Headphones", "Over-ear, 30-hour battery", "4999.00", 15, "Electronics"),
                    product("Laptop Backpack", "Water-resistant, fits 15.6 inch laptops", "1499.00", 30, "Accessories"),
                    product("Steel Water Bottle", "750 ml insulated bottle", "599.00", 60, "Accessories"),
                    product("Cotton T-Shirt", "Unisex round-neck, 100% cotton", "499.00", 100, "Clothing"),
                    product("Running Shoes", "Lightweight daily trainers", "2999.00", 20, "Clothing")));
        };
    }

    private static Product product(String name, String description, String price, int stock, String category) {
        Product p = new Product();
        p.setName(name);
        p.setDescription(description);
        p.setPrice(new BigDecimal(price));
        p.setStock(stock);
        p.setCategory(category);
        return p;
    }
}
