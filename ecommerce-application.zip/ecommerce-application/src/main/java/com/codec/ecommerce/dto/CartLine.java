package com.codec.ecommerce.dto;

import java.math.BigDecimal;

public record CartLine(Long productId, String name, BigDecimal price, int quantity, BigDecimal subtotal) {
}
