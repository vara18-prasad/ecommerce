package com.codec.ecommerce.model;

public enum OrderStatus {
    PLACED,          // cash on delivery: order accepted, payment due on delivery
    PAID,            // card payment approved
    PAYMENT_FAILED   // card payment declined; stock untouched, cart kept
}
