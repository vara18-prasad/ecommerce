package com.codec.ecommerce.dto;

import jakarta.validation.constraints.NotBlank;

/** paymentMethod: CARD or COD. cardNumber is only needed for CARD and is never stored. */
public record CheckoutRequest(
        @NotBlank(message = "paymentMethod is required") String paymentMethod,
        String cardNumber) {
}
