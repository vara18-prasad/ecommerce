package com.codec.ecommerce.controller;

import com.codec.ecommerce.dto.CheckoutRequest;
import com.codec.ecommerce.model.Order;
import com.codec.ecommerce.model.OrderStatus;
import com.codec.ecommerce.service.OrderService;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/api/orders")
public class OrderController {

    private final OrderService service;

    public OrderController(OrderService service) {
        this.service = service;
    }

    /** 201 when the order succeeds, 402 Payment Required when the simulated card is declined. */
    @PostMapping("/checkout/{userId}")
    public ResponseEntity<Order> checkout(@PathVariable String userId, @Valid @RequestBody CheckoutRequest request) {
        Order order = service.checkout(userId, request);
        HttpStatus status = order.getStatus() == OrderStatus.PAYMENT_FAILED
                ? HttpStatus.PAYMENT_REQUIRED : HttpStatus.CREATED;
        return ResponseEntity.status(status).body(order);
    }

    @GetMapping("/user/{userId}")
    public List<Order> history(@PathVariable String userId) {
        return service.forUser(userId);
    }

    @GetMapping("/{id}")
    public Order get(@PathVariable Long id) {
        return service.get(id);
    }
}
