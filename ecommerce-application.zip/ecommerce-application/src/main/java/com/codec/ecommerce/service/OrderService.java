package com.codec.ecommerce.service;

import com.codec.ecommerce.dto.CheckoutRequest;
import com.codec.ecommerce.exception.BadRequestException;
import com.codec.ecommerce.exception.ResourceNotFoundException;
import com.codec.ecommerce.model.CartItem;
import com.codec.ecommerce.model.Order;
import com.codec.ecommerce.model.OrderItem;
import com.codec.ecommerce.model.OrderStatus;
import com.codec.ecommerce.model.Product;
import com.codec.ecommerce.repository.CartItemRepository;
import com.codec.ecommerce.repository.OrderRepository;
import com.codec.ecommerce.repository.ProductRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;

@Service
public class OrderService {

    private final OrderRepository orderRepo;
    private final CartItemRepository cartRepo;
    private final ProductRepository productRepo;
    private final PaymentService paymentService;

    public OrderService(OrderRepository orderRepo, CartItemRepository cartRepo,
                        ProductRepository productRepo, PaymentService paymentService) {
        this.orderRepo = orderRepo;
        this.cartRepo = cartRepo;
        this.productRepo = productRepo;
        this.paymentService = paymentService;
    }

    /**
     * Cart -> order -> simulated payment, all in one transaction.
     * On success stock is reduced and the cart is emptied; on a declined card the order is
     * saved as PAYMENT_FAILED and the cart/stock are left untouched so the user can retry.
     */
    @Transactional
    public Order checkout(String userId, CheckoutRequest request) {
        List<CartItem> cart = cartRepo.findByUserId(userId);
        if (cart.isEmpty()) {
            throw new BadRequestException("Cart is empty");
        }

        Order order = new Order();
        order.setUserId(userId);
        order.setCreatedAt(LocalDateTime.now());
        order.setPaymentMethod(request.paymentMethod().toUpperCase());

        BigDecimal total = BigDecimal.ZERO;
        for (CartItem ci : cart) {
            Product product = ci.getProduct();
            if (ci.getQuantity() > product.getStock()) {
                throw new BadRequestException("Not enough stock for '" + product.getName()
                        + "' (available: " + product.getStock() + ")");
            }
            OrderItem line = new OrderItem();
            line.setProductId(product.getId());
            line.setProductName(product.getName());
            line.setUnitPrice(product.getPrice());
            line.setQuantity(ci.getQuantity());
            order.addItem(line);
            total = total.add(product.getPrice().multiply(BigDecimal.valueOf(ci.getQuantity())));
        }
        order.setTotalAmount(total);

        PaymentService.PaymentResult payment =
                paymentService.charge(request.paymentMethod(), request.cardNumber(), total);
        order.setPaymentReference(payment.reference());

        if (payment.success()) {
            order.setStatus("COD".equals(order.getPaymentMethod()) ? OrderStatus.PLACED : OrderStatus.PAID);
            for (CartItem ci : cart) {
                Product product = ci.getProduct();
                product.setStock(product.getStock() - ci.getQuantity());
                productRepo.save(product);
            }
            cartRepo.deleteByUserId(userId);
        } else {
            order.setStatus(OrderStatus.PAYMENT_FAILED);
        }
        return orderRepo.save(order);
    }

    @Transactional(readOnly = true)
    public List<Order> forUser(String userId) {
        return orderRepo.findByUserIdOrderByCreatedAtDesc(userId);
    }

    @Transactional(readOnly = true)
    public Order get(Long id) {
        return orderRepo.findById(id).orElseThrow(() -> new ResourceNotFoundException("Order " + id + " not found"));
    }
}
