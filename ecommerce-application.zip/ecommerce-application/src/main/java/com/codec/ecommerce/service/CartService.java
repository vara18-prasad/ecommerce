package com.codec.ecommerce.service;

import com.codec.ecommerce.dto.CartLine;
import com.codec.ecommerce.dto.CartView;
import com.codec.ecommerce.exception.BadRequestException;
import com.codec.ecommerce.exception.ResourceNotFoundException;
import com.codec.ecommerce.model.CartItem;
import com.codec.ecommerce.model.Product;
import com.codec.ecommerce.repository.CartItemRepository;
import com.codec.ecommerce.repository.ProductRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.util.List;

@Service
public class CartService {

    private final CartItemRepository cartRepo;
    private final ProductRepository productRepo;

    public CartService(CartItemRepository cartRepo, ProductRepository productRepo) {
        this.cartRepo = cartRepo;
        this.productRepo = productRepo;
    }

    @Transactional(readOnly = true)
    public CartView getCart(String userId) {
        List<CartLine> lines = cartRepo.findByUserId(userId).stream()
                .map(ci -> new CartLine(
                        ci.getProduct().getId(),
                        ci.getProduct().getName(),
                        ci.getProduct().getPrice(),
                        ci.getQuantity(),
                        ci.getProduct().getPrice().multiply(BigDecimal.valueOf(ci.getQuantity()))))
                .toList();
        BigDecimal total = lines.stream().map(CartLine::subtotal).reduce(BigDecimal.ZERO, BigDecimal::add);
        int count = lines.stream().mapToInt(CartLine::quantity).sum();
        return new CartView(userId, lines, count, total);
    }

    @Transactional
    public CartView addItem(String userId, Long productId, int quantity) {
        Product product = productRepo.findById(productId)
                .orElseThrow(() -> new ResourceNotFoundException("Product " + productId + " not found"));

        CartItem item = cartRepo.findByUserIdAndProductId(userId, productId).orElseGet(() -> {
            CartItem fresh = new CartItem();
            fresh.setUserId(userId);
            fresh.setProduct(product);
            fresh.setQuantity(0);
            return fresh;
        });

        int newQuantity = item.getQuantity() + quantity;
        checkStock(product, newQuantity);
        item.setQuantity(newQuantity);
        cartRepo.save(item);
        return getCart(userId);
    }

    @Transactional
    public CartView updateQuantity(String userId, Long productId, int quantity) {
        CartItem item = cartRepo.findByUserIdAndProductId(userId, productId)
                .orElseThrow(() -> new ResourceNotFoundException("Product " + productId + " is not in the cart"));
        if (quantity == 0) {
            cartRepo.delete(item);
        } else {
            checkStock(item.getProduct(), quantity);
            item.setQuantity(quantity);
            cartRepo.save(item);
        }
        return getCart(userId);
    }

    @Transactional
    public CartView removeItem(String userId, Long productId) {
        cartRepo.deleteByUserIdAndProductId(userId, productId);
        return getCart(userId);
    }

    @Transactional
    public void clear(String userId) {
        cartRepo.deleteByUserId(userId);
    }

    private void checkStock(Product product, int wanted) {
        if (wanted > product.getStock()) {
            throw new BadRequestException("Only " + product.getStock() + " unit(s) of '"
                    + product.getName() + "' in stock");
        }
    }
}
