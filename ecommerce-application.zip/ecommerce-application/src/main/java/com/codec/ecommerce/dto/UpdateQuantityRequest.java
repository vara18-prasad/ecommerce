package com.codec.ecommerce.dto;

import jakarta.validation.constraints.Min;

/** Quantity 0 removes the item from the cart. */
public record UpdateQuantityRequest(
        @Min(value = 0, message = "quantity cannot be negative") int quantity) {
}
