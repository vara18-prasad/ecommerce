package com.codec.ecommerce.dto;

import java.math.BigDecimal;
import java.util.List;

public record CartView(String userId, List<CartLine> items, int totalItems, BigDecimal total) {
}
