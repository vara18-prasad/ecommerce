package com.codec.ecommerce.controller;

import com.codec.ecommerce.dto.AddToCartRequest;
import com.codec.ecommerce.dto.CartView;
import com.codec.ecommerce.dto.UpdateQuantityRequest;
import com.codec.ecommerce.service.CartService;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

/** Carts are keyed by a userId in the URL (no login in this demo - see README for adding Spring Security). */
@RestController
@RequestMapping("/api/cart/{userId}")
public class CartController {

    private final CartService service;

    public CartController(CartService service) {
        this.service = service;
    }

    @GetMapping
    public CartView view(@PathVariable String userId) {
        return service.getCart(userId);
    }

    @PostMapping("/items")
    @ResponseStatus(HttpStatus.CREATED)
    public CartView add(@PathVariable String userId, @Valid @RequestBody AddToCartRequest request) {
        return service.addItem(userId, request.productId(), request.quantity());
    }

    @PutMapping("/items/{productId}")
    public CartView updateQuantity(@PathVariable String userId, @PathVariable Long productId,
                                   @Valid @RequestBody UpdateQuantityRequest request) {
        return service.updateQuantity(userId, productId, request.quantity());
    }

    @DeleteMapping("/items/{productId}")
    public CartView remove(@PathVariable String userId, @PathVariable Long productId) {
        return service.removeItem(userId, productId);
    }

    @DeleteMapping
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void clear(@PathVariable String userId) {
        service.clear(userId);
    }
}
