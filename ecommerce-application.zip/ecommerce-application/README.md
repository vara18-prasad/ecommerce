# E-Commerce Application

A backend for browsing and buying products, with a small demo storefront.
Built with **Java 17, Spring Boot 3, Hibernate (Spring Data JPA), REST APIs, H2 / MySQL**.

## Features

- **Product catalog** - list, search by name, filter by category, CRUD for products
- **Shopping cart** - add, change quantity, remove, clear; stock is checked on every change
- **Checkout with payment simulation** - card or cash on delivery
- **Order history** - orders store a snapshot of product name and price
- **Validation + error handling** - Bean Validation and a global JSON error handler
- **Transactional checkout** - order, stock reduction and cart clearing succeed or fail together

## Run it

Requirements: JDK 17+ and Maven.

```bash
mvn spring-boot:run
```

Open <http://localhost:8080> for the demo storefront. The default profile uses an in-memory
H2 database seeded with 8 products (console at `/h2-console`, JDBC URL `jdbc:h2:mem:shopdb`).

### Use MySQL instead

```bash
export DB_USERNAME=root
export DB_PASSWORD=your_password
mvn spring-boot:run -Dspring-boot.run.profiles=mysql
```

The `ecommerce_db` database is created automatically and Hibernate creates the tables.

## REST API

| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/api/products?q=&category=` | List / search products |
| GET | `/api/products/{id}` | Product details |
| POST | `/api/products` | Create product |
| PUT | `/api/products/{id}` | Update product |
| DELETE | `/api/products/{id}` | Delete product |
| GET | `/api/cart/{userId}` | View cart with totals |
| POST | `/api/cart/{userId}/items` | Add item `{ "productId": 1, "quantity": 2 }` |
| PUT | `/api/cart/{userId}/items/{productId}` | Set quantity (0 removes) |
| DELETE | `/api/cart/{userId}/items/{productId}` | Remove item |
| DELETE | `/api/cart/{userId}` | Clear cart |
| POST | `/api/orders/checkout/{userId}` | Checkout `{ "paymentMethod": "CARD", "cardNumber": "4242424242424242" }` |
| GET | `/api/orders/user/{userId}` | Order history |
| GET | `/api/orders/{id}` | Single order |

### Try it with curl

```bash
curl -X POST localhost:8080/api/cart/alice/items -H 'Content-Type: application/json' \
     -d '{"productId":1,"quantity":2}'
curl localhost:8080/api/cart/alice
curl -X POST localhost:8080/api/orders/checkout/alice -H 'Content-Type: application/json' \
     -d '{"paymentMethod":"CARD","cardNumber":"4242424242424242"}'
```

## Payment simulation

No real gateway is involved.

| Input | Result |
|-------|--------|
| `COD` | Order `PLACED` |
| `CARD`, 16 digits | Order `PAID` (HTTP 201) |
| `CARD` ending in `0000` | Order `PAYMENT_FAILED` (HTTP 402), stock and cart untouched |

Card numbers are validated in memory and never stored.

## Project structure

```
src/main/java/com/codec/ecommerce
 +-- model/        Product, CartItem, Order, OrderItem, OrderStatus (JPA entities)
 +-- repository/   Spring Data JPA repositories
 +-- service/      ProductService, CartService, OrderService, PaymentService
 +-- controller/   REST controllers
 +-- dto/          request/response records
 +-- exception/    custom exceptions + global handler
 +-- config/       demo data loader
```

## Known limitations / next steps

- No login: carts and orders are keyed by `userId` in the URL. Add Spring Security + JWT for real users.
- Concurrent checkouts of the last unit could oversell; add `@Version` optimistic locking on `Product`.
- Possible additions: pagination, product images, Swagger/OpenAPI, Docker Compose with MySQL.
